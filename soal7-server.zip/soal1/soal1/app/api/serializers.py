
from django.contrib.auth.models import User

from rest_framework import serializers

from app.models import (
    Chat,
)




class ChatSerializers(serializers.ModelSerializer):
    # image_url = serializers.ImageField(required=False)

    class Meta:
        model   = Chat
        fields  = ['image', 'md5']