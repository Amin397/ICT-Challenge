
from django.urls import path

from app.api.views import (
    add_item_view
    )

urlpatterns = [
    path('add/', add_item_view),
]