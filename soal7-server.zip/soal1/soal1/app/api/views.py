
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view

from app.api.serializers import (
    ChatSerializers,
)

from app.models import (
    Chat,
)


@api_view(['POST', ])
def add_item_view(request):
    print(request.data)

    serializer = ChatSerializers(data=request.data)
    if serializer.is_valid():
        md5 = request.data["md5"]
        print(md5)
        sum = Chat.objects.filter(md5=md5)
        try:
            sum[1]
            return Response(data=serializer.data, status=status.HTTP_200_OK)
        except:

        # item = Chat.objects.filter(md5=)
            serializer.save()
            print(serializer.data)
            return Response(data=serializer.data, status=status.HTTP_200_OK)
    else:
        print(serializer.errors)
        return Response(data=serializer.errors)

