from django.db import models


class Chat(models.Model):
    md5         = models.TextField(null=True, blank=True)
    image       = models.ImageField(upload_to='images/', null=True)